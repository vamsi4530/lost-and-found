"""
Competitive Analysis Agent powered by Ollama.

The agent identifies competitors, analyzes each one, and produces a
strategic report using the configured Ollama chat model.
"""

import argparse
import os
import re

import requests
from dotenv import load_dotenv

load_dotenv()

OLLAMA_HOST = os.getenv("OLLAMA_HOST", "http://localhost:11434")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "gpt-oss:120b-cloud")


def _call_ollama(prompt: str, system_prompt: str, model: str | None = None) -> str:
    model = model or OLLAMA_MODEL
    host = OLLAMA_HOST.rstrip("/")
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": prompt},
        ],
        "stream": False,
    }

    response = requests.post(f"{host}/api/chat", json=payload, timeout=180)
    response.raise_for_status()
    data = response.json()
    return data.get("message", {}).get("content", "").strip()


def identify_competitors(company: str, industry: str, model: str | None = None) -> list[str]:
    prompt = f"Company: {company}\nIndustry: {industry}\n\nList exactly 5 main competitors:"
    system_prompt = "You are a market researcher. Respond with exactly 5 competitors as a comma-separated list. Nothing else."
    response = _call_ollama(prompt, system_prompt, model=model)
    parts = re.split(r"[\n,;]+", response)
    competitors = [part.strip(" -•\t\r\n") for part in parts if part.strip()]
    return competitors[:5]


def analyze_competitor(company: str, competitor: str, industry: str, model: str | None = None) -> str:
    prompt = f"Analyze {competitor} for {company} in the {industry} market. Cover its main products, strengths, weaknesses, pricing model, and target market."
    system_prompt = "You are a strategy analyst. Write one concise paragraph under 120 words."
    return _call_ollama(prompt, system_prompt, model=model)


def generate_report(company: str, industry: str, competitor_analyses: dict[str, str], model: str | None = None) -> str:
    analyses_text = "\n\n".join(f"{name}:\n{analysis}" for name, analysis in competitor_analyses.items())
    prompt = f"Company: {company}\nIndustry: {industry}\n\nCompetitor analyses:\n{analyses_text}"
    system_prompt = (
        "You are a strategic consultant. Create a polished report with:"
        "1. Executive Summary (3 sentences), "
        "2. Competitive Landscape Table (company, strength, weakness, price), "
        "3. Market Gaps & Opportunities (3 bullet points), "
        "4. Strategic Recommendations (5 action items), "
        "5. Threat Assessment (High/Medium/Low for each competitor)."
    )
    return _call_ollama(prompt, system_prompt, model=model)


def run_competitive_analysis(company: str, industry: str, model: str | None = None) -> dict[str, object]:
    competitors = identify_competitors(company, industry, model=model)
    competitor_analyses = {}

    for competitor in competitors:
        competitor_analyses[competitor] = analyze_competitor(company, competitor, industry, model=model)

    final_report = generate_report(company, industry, competitor_analyses, model=model)
    return {
        "company": company,
        "industry": industry,
        "competitors": competitors,
        "competitor_analyses": competitor_analyses,
        "final_report": final_report,
        "model": model or OLLAMA_MODEL,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Competitive Analysis Agent")
    parser.add_argument("--company", default="Notion", help="Company to analyze")
    parser.add_argument("--industry", default="productivity and collaboration software", help="Industry")
    args = parser.parse_args()

    print(f"\n🔍 Analyzing competitive landscape for {args.company}...\n")

    try:
        result = run_competitive_analysis(args.company, args.industry)
    except requests.RequestException as exc:
        print(
            f"Unable to reach Ollama at {OLLAMA_HOST}. Start Ollama and ensure the model '{OLLAMA_MODEL}' is available.\n"
            f"Error: {exc}"
        )
        return 1

    print(f"🏢 Competitors identified: {', '.join(result['competitors'])}\n")
    print("=" * 60)
    print("📊 COMPETITIVE ANALYSIS REPORT")
    print("=" * 60)
    print(result["final_report"])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
