import os
from flask import Flask, render_template, request
from agent import run_competitive_analysis

app = Flask(__name__)
app.config["TEMPLATES_AUTO_RELOAD"] = True


@app.route("/", methods=["GET", "POST"])
def index():
    result = None
    error = None

    if request.method == "POST":
        company = request.form.get("company", "").strip()
        industry = request.form.get("industry", "").strip()

        if not company or not industry:
            error = "Please enter both a company and an industry."
        else:
            try:
                result = run_competitive_analysis(company, industry)
            except Exception as exc:
                error = str(exc)

    return render_template("index.html", result=result, error=error)


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=int(os.getenv("PORT", 5000)))
