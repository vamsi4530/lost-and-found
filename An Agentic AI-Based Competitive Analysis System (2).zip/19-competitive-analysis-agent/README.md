# Competitive Analysis Agent

A polished Flask web app for competitive analysis using Ollama.

## Features

- Beautiful responsive UI with HTML and CSS
- Company and industry form inputs
- Ollama-powered competitor research and report generation
- Works with models such as gpt-oss:120b-cloud

## Setup

```bash
pip install -r requirements.txt
```

Make sure Ollama is running locally and the requested model is available:

```bash
ollama pull gpt-oss:120b-cloud
```

You can override the model and host if needed:

```bash
set OLLAMA_HOST=http://localhost:11434
set OLLAMA_MODEL=gpt-oss:120b-cloud
```

## Run the web app

```bash
python app.py
```

Open http://127.0.0.1:5000

## Run the CLI version

```bash
python agent.py --company "Notion" --industry "productivity software"
```
